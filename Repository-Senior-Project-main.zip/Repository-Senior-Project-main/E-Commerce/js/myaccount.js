let fabar1 = document.querySelector('#fabar1');
let fabar2 = document.querySelector('#fabar2');
let fabar3 = document.querySelector('#fabar3');

// ////////////////////////////////////////////////////////
let sidebare = document.querySelector('.sidebare');
/////////////////////////////////////////////
fabar1.onclick = function () {
    sidebare.classList.toggle('close')
}
fabar2.onclick = function () {
    sidebare.classList.toggle('close')
}
fabar3.onclick = function () {
    sidebare.classList.toggle('close')
}
//////////////////////////////////////////////////////////
let menuitems = document.querySelectorAll('.menuitems');

function openitem() {
    menuitems.forEach((item) => item.classList.remove('close'));
    this.classList.add('close');
}

menuitems.forEach((item) => item.addEventListener('click', openitem));
//////////////////////////////////////////////////////////
