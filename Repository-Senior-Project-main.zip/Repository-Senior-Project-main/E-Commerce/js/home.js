const left_btn = document.querySelector(".left");
const right_btn = document.querySelector(".right");

right_btn.addEventListener('click', function (event) {
    console.log('do0ne');
    const x = document.querySelector('.items');
    x.scrollLeft += 1100;
    event.preventDefault();
});
left_btn.addEventListener('click', function (event) {
    console.log('do0ne');
    const x = document.querySelector('.items');
    x.scrollLeft -= 1100;
    event.preventDefault();
});


const v = document.querySelectorAll('.productsInSlider');
for (const i of v) {
    i.addEventListener('wheel', (evt) => {
        evt.preventDefault();
        i.scrollLeft += evt.deltaY;
    })
}

const vv = document.querySelectorAll('.items');
for (const i of vv) {
    i.addEventListener('wheel', (evt) => {
        evt.preventDefault();
        i.scrollLeft += evt.deltaY;
    })
}
